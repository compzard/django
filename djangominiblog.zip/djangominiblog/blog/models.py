from datetime import date

from django.contrib.auth.models import User
from django.db import models

# Create your models here.
from django.urls import reverse


class Blogger(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    bio = models.TextField(max_length=1000, help_text='Enter your Bio here')

    class Meta:
        ordering = ["user", "bio"]

    def get_absolute_url(self):
        """
            Returns the url to access to a particular  blogger instance
        """
        return reverse('blogger-post', args=[str(self.id)])

    def __str__(self):
        """
            String for representing the Model object.
        """
        return self.user.username


class Post(models.Model):
    """
        Model representing a blog Post
    """
    title = models.CharField(max_length=200)
    # Foreign Key used because Blog can only have one author/User, but bloggers can have multiple blog posts.
    author = models.ForeignKey(Blogger, on_delete=models.SET_NULL, null=True)
    description = models.TextField(max_length=2000, help_text="Enter you blog text here.")
    post_date = models.DateField(default=date.today)

    class Meta:
        ordering = ["post_date"]

    def get_absolute_url(self):
        """
        Returns the url to access a particular blog instance.
        """
        return reverse('post-detail', args=[str(self.id)])

    def __str__(self):
        """
        String for representing the Model object.
        :return:
        """
        return self.title


class BlogComment(models.Model):
    """
       Model representing a comment against a blog post.
    """
    description = models.TextField(max_length=1000, help_text="Enter comment about this post.")
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    post_date = models.DateTimeField(auto_now_add=True)
    blog = models.ForeignKey(Post, on_delete=models.CASCADE)

    def __str__(self):
        len_title = 75
        if len(self.description) > len_title:
            titleString = self.description[:len_title] + '...'
        else:
            titleString=self.description
        return titleString