from django.contrib import admin
from blog.models import Post, Blogger, BlogComment

# Register your models here.

# Minimal registration of Models.
admin.site.register(Blogger)
admin.site.register(BlogComment)


class BlogCommentInline(admin.TabularInline):
    """
       Used to show 'existing' blog comments inline below associated blogs
    """

    model = BlogComment


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    """
       Administration object for Blog models. 
       Defines:
        - fields to be displayed in list view (list_display)
        - orders fields in detail view (fields), grouping the date fields horizontally
        - adds inline addition of post comments in blog view (inlines)
       """
    list_display = ['title', 'author', 'post_date']
    inlines = [BlogCommentInline]