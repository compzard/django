from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, get_object_or_404

# Create your views here.
from django.urls import reverse
from django.views import generic
from django.views.generic import CreateView

from blog.models import Post, BlogComment, Blogger


def index(request):
    """
       View function for home page of site.
       """
    # Render the HTML template index.html
    return render(request, 'index.html')


class PostListView(generic.ListView):
    """
        Generic class-based view for a list of all blogs.
    """
    model = Post
    # This variable makes a pagination and also includes a template.
    paginate_by = 2


class PostDetailView(generic.DetailView):
    model = Post


class BloggerListView(generic.ListView):
    model = Blogger
    # This variable makes a pagination and also includes a template.
    # paginate_by = 2


class PostsListByAuthorView(generic.ListView):
    """
        Generic class-based view for a list of posts posted by a particular Blogger.
    """
    model = Post
    template_name = 'blog/blog_list_by_author.html'

    # This variable makes a pagination and also includes a template.
    # paginate_by = 2

    def get_queryset(self):
        """
            Return list of Blog objects created by Blogger (author id specified in URL)
        """
        id = self.kwargs['pk']
        target_author = get_object_or_404(Blogger, pk=id)
        return Post.objects.filter(author=target_author)

    def get_context_data(self, **kwargs):
        """
            Add Blogger to context so they can be displayed in the template
        """
        # Call the base implementation first to get a context
        context = super(PostsListByAuthorView, self).get_context_data(**kwargs)
        # Get the blogger object from the "pk" URL parameter and add it to the context
        context['blogger'] = get_object_or_404(Blogger, pk=self.kwargs['pk'])
        return context


class BlogCommentCreate(LoginRequiredMixin, CreateView):
    """
        Form for adding a blog comment. Requires login. 
    """
    model = BlogComment
    fields = ['description', ]

    def get_context_data(self, **kwargs):
        """
            Add associated blog to form template so can display its title in HTML.
        """
        # Call the base implementation first to get a context
        context = super(BlogCommentCreate, self).get_context_data(**kwargs)
        # Get the blog from id and add it to the context
        context['blog'] = get_object_or_404(Post, pk=self.kwargs['pk'])
        return context

    def form_valid(self, form):
        """
            Add author and associated blog to form data before setting it as valid (so it is saved to model)
        """
        # Add logged-in user as author of comment
        form.instance.author = self.request.user
        # Associate comment with blog based on passed id
        form.instance.blog = get_object_or_404(Post, pk=self.kwargs['pk'])
        # Call super-class form validation behaviour
        return super(BlogCommentCreate, self).form_valid(form)

    def get_success_url(self):
        """
           After posting comment return to associated blog.
        """
        return reverse('post-detail', kwargs={'pk': self.kwargs['pk']})
