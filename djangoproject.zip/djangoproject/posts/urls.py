# from django.conf.urls import url
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    # This get the details of a post by its ID.
    path('details/<int:id>/', views.details, name='details')
]